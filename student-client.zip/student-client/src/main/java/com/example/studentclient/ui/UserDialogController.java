package com.example.studentclient.ui;

import com.example.studentclient.api.Role;
import com.example.studentclient.api.dto.Dto.UserDto;
import com.example.studentclient.api.dto.Dto.UserRequest;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

import java.util.EnumSet;
import java.util.Locale;
import java.util.Set;

/**
 * Форма пользователя.
 * Создание: email, пароль, роли. Изменение: только роли — сервер (PUT /api/v1/users/{id})
 * находит пользователя по email и не меняет ни email, ни пароль.
 */
public class UserDialogController {
    private static final int MIN_PASSWORD = 4;

    @FXML private Label titleLabel;
    @FXML private Label subtitleLabel;
    @FXML private TextField emailField;
    @FXML private VBox passwordBox;
    @FXML private PasswordField passwordField;
    @FXML private CheckBox superAdminCheck;
    @FXML private CheckBox adminCheck;
    @FXML private CheckBox teacherCheck;
    @FXML private Label hintLabel;
    @FXML private Label errorLabel;

    private boolean editMode;
    private Set<String> existingEmails = Set.of();

    @FXML
    private void initialize() {
        emailField.textProperty().addListener((o, a, b) -> clearErrors());
        passwordField.textProperty().addListener((o, a, b) -> clearErrors());
        for (CheckBox c : checks()) {
            c.selectedProperty().addListener((o, a, b) -> Ui.setError(errorLabel, null));
        }
    }

    public void setupCreate(Set<String> existingEmailsLowerCase) {
        editMode = false;
        existingEmails = existingEmailsLowerCase;
        titleLabel.setText("Новый пользователь");
        subtitleLabel.setText("Учётная запись для входа в систему.");
        teacherCheck.setSelected(true);
        Platform.runLater(emailField::requestFocus);
    }

    public void setupEdit(UserDto user, boolean isSelf) {
        editMode = true;
        titleLabel.setText("Роли пользователя");
        subtitleLabel.setText("ID " + user.id());
        emailField.setText(user.email());
        emailField.setDisable(true);
        passwordBox.setVisible(false);
        passwordBox.setManaged(false);

        Set<Role> roles = user.roles();
        superAdminCheck.setSelected(roles.contains(Role.SUPER_ADMIN));
        adminCheck.setSelected(roles.contains(Role.ADMIN));
        teacherCheck.setSelected(roles.contains(Role.TEACHER));

        String hint = "Email и пароль изменить нельзя — доступно только изменение ролей.";
        if (isSelf) {
            // Права проверяются по ролям из БД при каждом запросе: сняв с себя SUPER_ADMIN,
            // администратор мгновенно потеряет доступ к этому разделу.
            superAdminCheck.setDisable(true);
            hint += "\nРоль «Супер-админ» нельзя снять с самого себя.";
        }
        Ui.setError(hintLabel, hint);
    }

    public boolean validate() {
        emailField.getStyleClass().remove("invalid");
        passwordField.getStyleClass().remove("invalid");

        if (!editMode) {
            String email = emailField.getText().trim();
            if (email.isEmpty()) {
                return fail(emailField, "Укажите email.");
            }
            if (!Ui.EMAIL.matcher(email).matches()) {
                return fail(emailField, "Некорректный email.");
            }
            // Сервер на дубликат отвечает ошибкой без пояснений — проверяем заранее.
            if (existingEmails.contains(email.toLowerCase(Locale.ROOT))) {
                return fail(emailField, "Пользователь с таким email уже существует.");
            }
            if (passwordField.getText().length() < MIN_PASSWORD) {
                return fail(passwordField, "Пароль должен быть не короче " + MIN_PASSWORD + " символов.");
            }
        }
        if (selectedRoles().isEmpty()) {
            showError("Выберите хотя бы одну роль.");
            return false;
        }
        return true;
    }

    public UserRequest buildRequest() {
        return new UserRequest(emailField.getText().trim(), passwordField.getText(), selectedRoles());
    }

    public Set<Role> selectedRoles() {
        Set<Role> roles = EnumSet.noneOf(Role.class);
        if (superAdminCheck.isSelected()) {
            roles.add(Role.SUPER_ADMIN);
        }
        if (adminCheck.isSelected()) {
            roles.add(Role.ADMIN);
        }
        if (teacherCheck.isSelected()) {
            roles.add(Role.TEACHER);
        }
        return roles;
    }

    public void showError(String message) {
        Ui.setError(errorLabel, message);
    }

    private boolean fail(TextField field, String message) {
        field.getStyleClass().add("invalid");
        field.requestFocus();
        showError(message);
        return false;
    }

    private void clearErrors() {
        emailField.getStyleClass().remove("invalid");
        passwordField.getStyleClass().remove("invalid");
        Ui.setError(errorLabel, null);
    }

    private CheckBox[] checks() {
        return new CheckBox[]{superAdminCheck, adminCheck, teacherCheck};
    }
}
