package com.example.studentclient.ui;

import com.example.studentclient.AppContext;
import com.example.studentclient.api.ApiClient;
import com.example.studentclient.api.Role;
import com.example.studentclient.api.dto.Dto.UserDto;
import javafx.beans.binding.Bindings;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.HBox;
import javafx.stage.Window;

import java.util.EnumSet;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

/** Вкладка «Пользователи» — доступна только SUPER_ADMIN. */
public class UsersController {
    @FXML private TextField searchField;
    @FXML private Button refreshButton;
    @FXML private Button addButton;
    @FXML private Button editButton;
    @FXML private Button deleteButton;

    @FXML private TableView<UserDto> table;
    @FXML private TableColumn<UserDto, Number> idColumn;
    @FXML private TableColumn<UserDto, String> emailColumn;
    @FXML private TableColumn<UserDto, Set<Role>> rolesColumn;
    @FXML private Label tablePlaceholder;

    @FXML private Label countLabel;
    @FXML private ProgressIndicator loadingIndicator;

    private final ApiClient api = AppContext.api();
    private final ObservableList<UserDto> items = FXCollections.observableArrayList();
    private FilteredList<UserDto> filtered;
    private String myEmail;

    @FXML
    private void initialize() {
        myEmail = api.session().email();

        idColumn.setCellValueFactory(c -> new SimpleLongProperty(c.getValue().id()));
        emailColumn.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().email()));
        emailColumn.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String email, boolean empty) {
                super.updateItem(email, empty);
                if (empty || email == null) {
                    setText(null);
                    setGraphic(null);
                    return;
                }
                setText(email);
                if (isMe(email)) {
                    Label me = new Label("это вы");
                    me.getStyleClass().addAll("chip", "chip-me");
                    setGraphic(me);
                    setContentDisplay(javafx.scene.control.ContentDisplay.RIGHT);
                } else {
                    setGraphic(null);
                }
            }
        });
        rolesColumn.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().roles()));
        rolesColumn.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(Set<Role> roles, boolean empty) {
                super.updateItem(roles, empty);
                setText(null);
                if (empty || roles == null) {
                    setGraphic(null);
                    return;
                }
                HBox box = new HBox(4);
                for (Role r : Role.values()) {
                    if (roles.contains(r)) {
                        Label chip = new Label(r.title());
                        chip.getStyleClass().addAll("chip", "chip-" + r.name().toLowerCase().replace('_', '-'));
                        box.getChildren().add(chip);
                    }
                }
                if (box.getChildren().isEmpty()) {
                    Label none = new Label("нет ролей");
                    none.getStyleClass().add("muted");
                    box.getChildren().add(none);
                }
                setGraphic(box);
            }
        });

        filtered = new FilteredList<>(items, u -> true);
        SortedList<UserDto> sorted = new SortedList<>(filtered);
        sorted.comparatorProperty().bind(table.comparatorProperty());
        table.setItems(sorted);
        table.getSortOrder().add(idColumn);

        searchField.textProperty().addListener((o, a, text) -> applyFilter(text));

        var selected = table.getSelectionModel().selectedItemProperty();
        editButton.disableProperty().bind(selected.isNull());
        // Удалить самого себя нельзя — иначе SUPER_ADMIN сразу потеряет доступ.
        deleteButton.disableProperty().bind(Bindings.createBooleanBinding(
                () -> selected.get() == null || isMe(selected.get().email()), selected));

        table.setRowFactory(tv -> {
            TableRow<UserDto> row = new TableRow<>();
            row.setOnMouseClicked(e -> {
                if (e.getButton() == MouseButton.PRIMARY && e.getClickCount() == 2 && !row.isEmpty()) {
                    onEdit();
                }
            });
            return row;
        });

        reload(null);
    }

    // ===================== Действия =====================

    @FXML
    private void onRefresh() {
        UserDto selected = table.getSelectionModel().getSelectedItem();
        reload(selected == null ? null : selected.id());
    }

    @FXML
    private void onAdd() {
        FXMLLoader loader = AppContext.loader("user-dialog.fxml");
        DialogPane pane = AppContext.load(loader);
        UserDialogController form = loader.getController();
        Set<String> existing = items.stream()
                .map(u -> u.email().toLowerCase(Locale.ROOT))
                .collect(Collectors.toSet());
        form.setupCreate(existing);

        Ui.showForm(window(), "Новый пользователь", pane, "Создать",
                form::validate,
                () -> api.createUser(form.buildRequest()),
                form::showError
        ).ifPresent(created -> reload(created.id()));
    }

    @FXML
    private void onEdit() {
        UserDto user = table.getSelectionModel().getSelectedItem();
        if (user == null) {
            return;
        }
        FXMLLoader loader = AppContext.loader("user-dialog.fxml");
        DialogPane pane = AppContext.load(loader);
        UserDialogController form = loader.getController();
        form.setupEdit(user, isMe(user.email()));

        Ui.showForm(window(), "Роли пользователя", pane, "Сохранить",
                form::validate,
                () -> {
                    api.updateUserRoles(user.id(), user.email(), form.selectedRoles());
                    return Boolean.TRUE;
                },
                form::showError
        ).ifPresent(ok -> reload(user.id()));
    }

    @FXML
    private void onDelete() {
        UserDto user = table.getSelectionModel().getSelectedItem();
        if (user == null || isMe(user.email())) {
            return;
        }
        boolean ok = Ui.confirm(window(), "Удалить пользователя?",
                "Учётная запись «" + user.email() + "» будет удалена, вход под ней станет невозможен.",
                "Удалить");
        if (!ok) {
            return;
        }
        setLoading(true);
        Async.run(() -> {
            api.deleteUser(user.id());
            return null;
        }, v -> reload(null), ex -> {
            setLoading(false);
            Ui.showError(window(), ex);
        });
    }

    // ===================== Вспомогательное =====================

    private void reload(Long selectId) {
        setLoading(true);
        tablePlaceholder.setText("Загрузка…");
        Async.run(api::getUsers, list -> {
            setLoading(false);
            items.setAll(list.responses().stream()
                    .map(u -> new UserDto(u.id(), u.email(),
                            u.roles() == null ? EnumSet.noneOf(Role.class) : u.roles()))
                    .toList());
            tablePlaceholder.setText("Пользователей нет");
            updateCount();
            if (selectId != null) {
                table.getItems().stream().filter(u -> u.id() == selectId).findFirst().ifPresent(u -> {
                    table.getSelectionModel().select(u);
                    table.scrollTo(u);
                });
            }
        }, ex -> {
            setLoading(false);
            tablePlaceholder.setText("Не удалось загрузить список");
            Ui.showError(window(), ex);
        });
    }

    private void applyFilter(String text) {
        String q = text == null ? "" : text.trim().toLowerCase(Locale.ROOT);
        filtered.setPredicate(u -> q.isEmpty()
                || (u.email() != null && u.email().toLowerCase(Locale.ROOT).contains(q))
                || u.roles().stream().anyMatch(r -> r.name().toLowerCase(Locale.ROOT).contains(q)
                || r.title().toLowerCase(Locale.ROOT).contains(q)));
        updateCount();
    }

    private void updateCount() {
        String text = "Всего пользователей: " + items.size();
        if (filtered.size() != items.size()) {
            text += "  ·  найдено: " + filtered.size();
        }
        countLabel.setText(text);
    }

    private boolean isMe(String email) {
        return email != null && email.equalsIgnoreCase(myEmail);
    }

    private void setLoading(boolean loading) {
        loadingIndicator.setVisible(loading);
        refreshButton.setDisable(loading);
    }

    private Window window() {
        return table.getScene().getWindow();
    }
}
