package com.example.studentclient;

import com.example.studentclient.api.ApiClient;
import com.example.studentclient.ui.LoginController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.net.URL;
import java.util.prefs.Preferences;

/**
 * Общие объекты приложения: главное окно, API-клиент, настройки и переключение экранов.
 */
public final class AppContext {
    public static final String STYLESHEET = resource("styles.css").toExternalForm();

    private static final ApiClient API = new ApiClient();
    private static final Preferences PREFS = Preferences.userNodeForPackage(AppContext.class);
    private static Stage stage;

    private AppContext() {
    }

    static void init(Stage primaryStage) {
        stage = primaryStage;
    }

    public static ApiClient api() {
        return API;
    }

    public static Preferences prefs() {
        return PREFS;
    }

    public static Stage stage() {
        return stage;
    }

    /** Экран входа. message — необязательное сообщение (например, "сессия истекла"). */
    public static void showLogin(String message) {
        API.logout();
        FXMLLoader loader = loader("login.fxml");
        Parent root = load(loader);
        LoginController controller = loader.getController();
        controller.setMessage(message);
        setScene(root, 460, 620, false);
    }

    public static void showMain() {
        Parent root = load(loader("main.fxml"));
        setScene(root, 1120, 700, true);
        stage.setMinWidth(860);
        stage.setMinHeight(520);
    }

    public static FXMLLoader loader(String fxml) {
        return new FXMLLoader(resource(fxml));
    }

    public static <T> T load(FXMLLoader loader) {
        try {
            return loader.load();
        } catch (IOException e) {
            throw new UncheckedIOException("Не удалось загрузить " + loader.getLocation(), e);
        }
    }

    public static URL resource(String name) {
        URL url = AppContext.class.getResource(name);
        if (url == null) {
            throw new IllegalStateException("Ресурс не найден: " + name);
        }
        return url;
    }

    private static void setScene(Parent root, double width, double height, boolean resizable) {
        Scene scene = new Scene(root, width, height);
        scene.getStylesheets().add(STYLESHEET);
        stage.setMinWidth(0);
        stage.setMinHeight(0);
        stage.setScene(scene);
        stage.setResizable(resizable);
        stage.sizeToScene();
        stage.centerOnScreen();
    }
}
