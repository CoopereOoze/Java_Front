package com.example.studentclient.api;

import java.time.Instant;
import java.util.Collections;
import java.util.EnumSet;
import java.util.Set;

/** Данные текущего входа: JWT, email и роли. */
public final class Session {
    private final String token;
    private final String email;
    private final Set<Role> roles;
    private final Instant expiresAt;

    public Session(String token, String email, Set<Role> roles, Instant expiresAt) {
        this.token = token;
        this.email = email;
        this.roles = roles.isEmpty() ? EnumSet.noneOf(Role.class) : EnumSet.copyOf(roles);
        this.expiresAt = expiresAt;
    }

    public String token() {
        return token;
    }

    public String email() {
        return email;
    }

    public Set<Role> roles() {
        return Collections.unmodifiableSet(roles);
    }

    public boolean hasRole(Role role) {
        return roles.contains(role);
    }

    public boolean hasAnyRole(Role... wanted) {
        for (Role r : wanted) {
            if (roles.contains(r)) {
                return true;
            }
        }
        return false;
    }

    public boolean isExpired() {
        return Instant.now().isAfter(expiresAt);
    }
}
