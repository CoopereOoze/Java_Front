package com.example.studentclient.ui;

import com.example.studentclient.AppContext;
import com.example.studentclient.api.ApiException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.layout.Region;
import javafx.stage.Window;

import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.regex.Pattern;

/** Общие UI-утилиты: сообщения об ошибках, подтверждения, диалоги-формы, валидация. */
public final class Ui {
    public static final Pattern EMAIL = Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");
    public static final Pattern PHONE = Pattern.compile("^[+0-9()\\-\\s]{5,20}$");

    private Ui() {
    }

    public static String message(Throwable ex) {
        if (ex instanceof ApiException api) {
            return api.getMessage();
        }
        String m = ex.getMessage();
        return m == null || m.isBlank() ? ex.getClass().getSimpleName() : m;
    }

    public static boolean isUnauthorized(Throwable ex) {
        return ex instanceof ApiException api && api.kind() == ApiException.Kind.UNAUTHORIZED;
    }

    /** Показывает ошибку; если сессия истекла — возвращает на экран входа. */
    public static void showError(Window owner, Throwable ex) {
        if (isUnauthorized(ex)) {
            AppContext.showLogin(message(ex));
            return;
        }
        Alert alert = new Alert(Alert.AlertType.ERROR);
        style(alert, owner);
        alert.setTitle("Ошибка");
        alert.setHeaderText("Не удалось выполнить действие");
        alert.setContentText(message(ex));
        alert.showAndWait();
    }

    public static boolean confirm(Window owner, String header, String text, String okText) {
        ButtonType ok = new ButtonType(okText, ButtonBar.ButtonData.OK_DONE);
        ButtonType cancel = new ButtonType("Отмена", ButtonBar.ButtonData.CANCEL_CLOSE);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, text, ok, cancel);
        style(alert, owner);
        alert.setTitle("Подтверждение");
        alert.setHeaderText(header);
        alert.getDialogPane().lookupButton(ok).getStyleClass().add("danger");
        return alert.showAndWait().filter(ok::equals).isPresent();
    }

    /**
     * Модальная форма: по кнопке OK проверяет поля, выполняет запрос в фоне и закрывается
     * только при успехе. Ошибка выводится внутри формы через showError.
     *
     * @return результат submit, если форма успешно сохранена
     */
    public static <T> Optional<T> showForm(Window owner, String title, DialogPane pane, String okText,
                                           BooleanSupplier validate, Callable<T> submit,
                                           Consumer<String> showError) {
        Dialog<T> dialog = new Dialog<>();
        dialog.initOwner(owner);
        dialog.setTitle(title);
        dialog.setDialogPane(pane);
        pane.getStylesheets().add(AppContext.STYLESHEET);

        ButtonType okType = new ButtonType(okText, ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelType = new ButtonType("Отмена", ButtonBar.ButtonData.CANCEL_CLOSE);
        pane.getButtonTypes().setAll(okType, cancelType);
        Button ok = (Button) pane.lookupButton(okType);
        Node cancel = pane.lookupButton(cancelType);

        AtomicReference<T> result = new AtomicReference<>();
        AtomicBoolean saved = new AtomicBoolean(false);
        dialog.setResultConverter(bt -> bt == okType && saved.get() ? result.get() : null);

        ok.addEventFilter(ActionEvent.ACTION, e -> {
            if (saved.get()) {
                return; // запрос выполнен — пропускаем событие, диалог закроется
            }
            e.consume();
            if (!validate.getAsBoolean()) {
                return;
            }
            setBusy(pane, ok, cancel, true);
            Async.run(submit, value -> {
                result.set(value);
                saved.set(true);
                setBusy(pane, ok, cancel, false);
                ok.fire();
            }, ex -> {
                setBusy(pane, ok, cancel, false);
                if (isUnauthorized(ex)) {
                    dialog.close();
                    showError(owner, ex);
                } else {
                    showError.accept(message(ex));
                }
            });
        });
        dialog.setOnShown(e -> fitDialog(pane));
        dialog.setResizable(true);
        return dialog.showAndWait();
    }

    /** Показывает/скрывает текст ошибки в форме (label должен иметь managed=false по умолчанию). */
    public static void setError(Label label, String text) {
        boolean show = text != null && !text.isBlank();
        label.setText(show ? text : "");
        label.setVisible(show);
        label.setManaged(show);
        // Перенесённый текст не должен обрезаться многоточием.
        label.setMinHeight(Region.USE_PREF_SIZE);
        fitDialog(label);
    }

    /**
     * Если надпись находится в диалоге, подгоняет размер окна под новое содержимое,
     * чтобы появившееся сообщение не перекрывало и не обрезало кнопки.
     */
    private static void fitDialog(Node node) {
        Scene scene = node.getScene();
        if (scene == null || !(scene.getRoot() instanceof DialogPane pane)) {
            return;
        }
        Platform.runLater(() -> {
            pane.requestLayout();
            Window window = scene.getWindow();
            if (window != null) {
                window.sizeToScene();
            }
        });
    }

    public static String trimToNull(String s) {
        if (s == null) {
            return null;
        }
        String t = s.trim();
        return t.isEmpty() ? null : t;
    }

    public static String orDash(String s) {
        return s == null || s.isBlank() ? "—" : s;
    }

    private static void setBusy(DialogPane pane, Button ok, Node cancel, boolean busy) {
        ok.setDisable(busy);
        cancel.setDisable(busy);
        pane.setCursor(busy ? Cursor.WAIT : Cursor.DEFAULT);
    }

    private static void style(Alert alert, Window owner) {
        if (owner != null) {
            alert.initOwner(owner);
        }
        alert.getDialogPane().getStylesheets().add(AppContext.STYLESHEET);
    }
}
