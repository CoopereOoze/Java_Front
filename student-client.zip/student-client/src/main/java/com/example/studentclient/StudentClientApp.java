package com.example.studentclient;

import javafx.application.Application;
import javafx.stage.Stage;

public class StudentClientApp extends Application {

    @Override
    public void start(Stage stage) {
        stage.setTitle("Учёт студентов");
        AppContext.init(stage);
        AppContext.showLogin(null);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
