package com.example.studentclient.api;

/** Ошибка обращения к серверу с понятным пользователю сообщением. */
public class ApiException extends Exception {

    public enum Kind {
        /** Сервер недоступен / таймаут. */
        CONNECTION,
        /** Токен отсутствует, истёк или неверен — нужно войти заново. */
        UNAUTHORIZED,
        /** Недостаточно прав (или сервер скрыл ошибку за 403). */
        FORBIDDEN,
        NOT_FOUND,
        BAD_REQUEST,
        SERVER
    }

    private final Kind kind;
    private final int status;

    public ApiException(Kind kind, int status, String message) {
        super(message);
        this.kind = kind;
        this.status = status;
    }

    public ApiException(Kind kind, String message, Throwable cause) {
        super(message, cause);
        this.kind = kind;
        this.status = 0;
    }

    public Kind kind() {
        return kind;
    }

    /** HTTP-статус, 0 — если ответа не было. */
    public int status() {
        return status;
    }
}
