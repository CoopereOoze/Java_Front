package com.example.studentclient.ui;

import com.example.studentclient.api.dto.Dto.StudentCreateRequest;
import com.example.studentclient.api.dto.Dto.StudentFull;
import com.example.studentclient.api.dto.Dto.StudentUpdateRequest;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/** Форма создания / изменения студента. */
public class StudentDialogController {
    @FXML private Label titleLabel;
    @FXML private Label subtitleLabel;
    @FXML private TextField nameField;
    @FXML private TextField surnameField;
    @FXML private TextField phoneField;
    @FXML private TextField emailField;
    @FXML private Label hintLabel;
    @FXML private Label errorLabel;

    private boolean editMode;

    @FXML
    private void initialize() {
        for (TextField f : new TextField[]{nameField, surnameField, phoneField, emailField}) {
            f.textProperty().addListener((o, a, b) -> {
                f.getStyleClass().remove("invalid");
                Ui.setError(errorLabel, null);
            });
        }
    }

    public void setupCreate() {
        editMode = false;
        titleLabel.setText("Новый студент");
        subtitleLabel.setText("Поля, отмеченные *, обязательны.");
        Platform.runLater(nameField::requestFocus);
    }

    public void setupEdit(StudentFull s) {
        editMode = true;
        titleLabel.setText("Изменение студента");
        subtitleLabel.setText("ID " + s.id());
        nameField.setText(nz(s.name()));
        surnameField.setText(nz(s.surname()));
        phoneField.setText(nz(s.phoneNumber()));
        emailField.setText(nz(s.email()));
        nameField.setDisable(true);
        surnameField.setDisable(true);
        Ui.setError(hintLabel, "Имя и фамилию изменить нельзя — доступно изменение телефона и email.");
        Platform.runLater(phoneField::requestFocus);
    }

    public boolean validate() {
        clearInvalid();
        if (!editMode) {
            if (nameField.getText().isBlank()) {
                return fail(nameField, "Укажите имя.");
            }
            if (surnameField.getText().isBlank()) {
                return fail(surnameField, "Укажите фамилию.");
            }
        }
        String phone = phoneField.getText().trim();
        if (!phone.isEmpty() && !Ui.PHONE.matcher(phone).matches()) {
            return fail(phoneField, "Телефон может содержать только цифры, пробелы, +, -, скобки (5–20 символов).");
        }
        String email = emailField.getText().trim();
        if (!email.isEmpty() && !Ui.EMAIL.matcher(email).matches()) {
            return fail(emailField, "Некорректный email.");
        }
        return true;
    }

    public StudentCreateRequest buildCreateRequest() {
        return new StudentCreateRequest(
                nameField.getText().trim(),
                surnameField.getText().trim(),
                Ui.trimToNull(phoneField.getText()),
                Ui.trimToNull(emailField.getText()));
    }

    /** Пустая строка очищает поле на сервере (null сервер трактует как «не менять»). */
    public StudentUpdateRequest buildUpdateRequest() {
        return new StudentUpdateRequest(phoneField.getText().trim(), emailField.getText().trim());
    }

    public void showError(String message) {
        Ui.setError(errorLabel, message);
    }

    private boolean fail(TextField field, String message) {
        field.getStyleClass().add("invalid");
        field.requestFocus();
        showError(message);
        return false;
    }

    private void clearInvalid() {
        for (TextField f : new TextField[]{nameField, surnameField, phoneField, emailField}) {
            f.getStyleClass().remove("invalid");
        }
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
