package com.example.studentclient.api.dto;

import com.example.studentclient.api.Role;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Set;

/**
 * DTO, повторяющие JSON-контракт сервера (пакет com.example.student.dto).
 * Неизвестные поля игнорируются настройкой ObjectMapper в ApiClient.
 */
public final class Dto {
    private Dto() {
    }

    // ---------- Авторизация ----------

    /** POST /api/v1/auth/login */
    public record LoginRequest(String email, String password) {
    }

    /** Ответ на вход. roles приходят в виде "ROLE_ADMIN". */
    public record AuthResponse(String token, String type, int expiresIn, List<String> roles) {
    }

    // ---------- Студенты ----------

    /** Элемент списка GET /api/v1/student и ответ на создание/изменение. */
    public record StudentShort(long id, String name, String surname) {
        public String fullName() {
            return (nz(name) + " " + nz(surname)).trim();
        }
    }

    /** GET /api/v1/student -> { "response": [...], "totalCount": N } */
    public record StudentList(List<StudentShort> response, int totalCount) {
    }

    /** GET /api/v1/student/{id} — здесь телефон приходит как phoneNumber. */
    public record StudentFull(long id, String name, String surname, String phoneNumber, String email) {
        public String fullName() {
            return (nz(name) + " " + nz(surname)).trim();
        }
    }

    /** POST /api/v1/student/save — сервер ждёт телефон в поле phone_number. */
    public record StudentCreateRequest(String name,
                                       String surname,
                                       @JsonProperty("phone_number") String phoneNumber,
                                       String email) {
    }

    /**
     * PUT /api/v1/student/{id} — сервер позволяет менять только телефон и email.
     * null означает «не менять», пустая строка — «очистить».
     */
    public record StudentUpdateRequest(String phoneNumber, String email) {
    }

    // ---------- Пользователи (только SUPER_ADMIN) ----------

    public record UserDto(long id, String email, Set<Role> roles) {
    }

    /** GET /api/v1/users -> { "responses": [...], "totalCount": N } */
    public record UserList(List<UserDto> responses, int totalCount) {
    }

    /** POST /api/v1/users/save и PUT /api/v1/users/{id}. */
    public record UserRequest(String email, String password, Set<Role> roles) {
    }

    // ---------- Ошибки ----------

    /** Тело ошибки из GlobalExceptionHandler: { "statusCode": 404, "message": "..." }. */
    public record AppError(Integer statusCode, String message, String error) {
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
