package com.example.studentclient.api;

import java.util.Optional;

/** Роли пользователя — совпадают с com.example.student.model.Role на сервере. */
public enum Role {
    SUPER_ADMIN("Супер-админ"),
    ADMIN("Администратор"),
    TEACHER("Преподаватель");

    private final String title;

    Role(String title) {
        this.title = title;
    }

    public String title() {
        return title;
    }

    /** Принимает как "ADMIN", так и "ROLE_ADMIN" (так роли приходят в ответе на /auth/login). */
    public static Optional<Role> parse(String value) {
        if (value == null) {
            return Optional.empty();
        }
        String name = value.startsWith("ROLE_") ? value.substring(5) : value;
        try {
            return Optional.of(Role.valueOf(name));
        } catch (IllegalArgumentException e) {
            return Optional.empty();
        }
    }
}
