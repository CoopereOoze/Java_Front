package com.example.studentclient;

/**
 * Точка входа для запуска из "толстого" jar и из IDE без настройки module-path.
 * JavaFX требует, чтобы main-класс не наследовал Application, если JavaFX лежит в classpath.
 */
public final class Launcher {
    public static void main(String[] args) {
        StudentClientApp.main(args);
    }
}
