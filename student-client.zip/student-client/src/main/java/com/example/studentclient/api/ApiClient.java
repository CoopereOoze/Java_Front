package com.example.studentclient.api;

import com.example.studentclient.api.dto.Dto.AppError;
import com.example.studentclient.api.dto.Dto.AuthResponse;
import com.example.studentclient.api.dto.Dto.LoginRequest;
import com.example.studentclient.api.dto.Dto.StudentCreateRequest;
import com.example.studentclient.api.dto.Dto.StudentFull;
import com.example.studentclient.api.dto.Dto.StudentList;
import com.example.studentclient.api.dto.Dto.StudentShort;
import com.example.studentclient.api.dto.Dto.StudentUpdateRequest;
import com.example.studentclient.api.dto.Dto.UserDto;
import com.example.studentclient.api.dto.Dto.UserList;
import com.example.studentclient.api.dto.Dto.UserRequest;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.ConnectException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpConnectTimeoutException;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/**
 * Обёртка над REST API сервера fun-student.
 * Все методы блокирующие — вызывайте их из фонового потока (см. ui.Async).
 */
public class ApiClient {
    public static final String DEFAULT_BASE_URL = "http://localhost:8080";

    private static final Duration CONNECT_TIMEOUT = Duration.ofSeconds(5);
    private static final Duration REQUEST_TIMEOUT = Duration.ofSeconds(15);

    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(CONNECT_TIMEOUT)
            .build();

    private final ObjectMapper mapper = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
            .setSerializationInclusion(JsonInclude.Include.NON_NULL);

    private volatile String baseUrl = DEFAULT_BASE_URL;
    private volatile Session session;

    // ===================== Авторизация =====================

    /** Вход. При успехе сохраняет сессию и возвращает её. */
    public Session login(String serverUrl, String email, String password) throws ApiException {
        this.baseUrl = normalizeBaseUrl(serverUrl);
        HttpResponse<String> resp = send(build("POST", "/api/v1/auth/login",
                new LoginRequest(email, password), false));

        int code = resp.statusCode();
        if (code == 401 || code == 403) {
            throw new ApiException(ApiException.Kind.UNAUTHORIZED, code, "Неверный email или пароль.");
        }
        if (code == 400) {
            throw new ApiException(ApiException.Kind.BAD_REQUEST, code, "Проверьте правильность email и пароля.");
        }
        ensureSuccess(resp);

        AuthResponse auth = parse(resp, AuthResponse.class);
        if (auth == null || auth.token() == null || auth.token().isBlank()) {
            throw new ApiException(ApiException.Kind.SERVER, code, "Не удалось выполнить вход. Попробуйте ещё раз.");
        }
        Set<Role> roles = EnumSet.noneOf(Role.class);
        if (auth.roles() != null) {
            auth.roles().forEach(r -> Role.parse(r).ifPresent(roles::add));
        }
        // Небольшой запас, чтобы не отправить запрос с токеном, истекающим «на лету».
        long ttl = auth.expiresIn() > 0 ? auth.expiresIn() : 3600;
        Instant expiresAt = Instant.now().plusSeconds(Math.max(ttl - 30, 0));

        session = new Session(auth.token(), email, roles, expiresAt);
        return session;
    }

    public void logout() {
        session = null;
    }

    public Session session() {
        return session;
    }

    public String baseUrl() {
        return baseUrl;
    }

    // ===================== Студенты =====================

    public StudentList getStudents() throws ApiException {
        StudentList list = call("GET", "/api/v1/student", null, StudentList.class);
        return list != null && list.response() != null ? list : new StudentList(List.of(), 0);
    }

    public StudentFull getStudent(long id) throws ApiException {
        return call("GET", "/api/v1/student/" + id, null, StudentFull.class);
    }

    public StudentShort createStudent(StudentCreateRequest request) throws ApiException {
        return call("POST", "/api/v1/student/save", request, StudentShort.class);
    }

    public StudentShort updateStudent(long id, StudentUpdateRequest request) throws ApiException {
        return call("PUT", "/api/v1/student/" + id, request, StudentShort.class);
    }

    public void deleteStudent(long id) throws ApiException {
        call("DELETE", "/api/v1/student/" + id, null, Void.class);
    }

    // ===================== Пользователи =====================

    public UserList getUsers() throws ApiException {
        UserList list = call("GET", "/api/v1/users", null, UserList.class);
        return list != null && list.responses() != null ? list : new UserList(List.of(), 0);
    }

    public UserDto createUser(UserRequest request) throws ApiException {
        return call("POST", "/api/v1/users/save", request, UserDto.class);
    }

    /**
     * Сервер ищет пользователя по email из тела (id в пути не используется),
     * меняет только роли и отвечает пустым телом — поэтому метод ничего не возвращает.
     */
    public void updateUserRoles(long id, String email, Set<Role> roles) throws ApiException {
        call("PUT", "/api/v1/users/" + id, new UserRequest(email, null, roles), Void.class);
    }

    public void deleteUser(long id) throws ApiException {
        call("DELETE", "/api/v1/users/" + id, null, Void.class);
    }

    // ===================== Внутреннее =====================

    private <T> T call(String method, String path, Object body, Class<T> type) throws ApiException {
        Session s = session;
        if (s == null || s.isExpired()) {
            throw new ApiException(ApiException.Kind.UNAUTHORIZED, 401, "Сессия истекла. Войдите снова.");
        }
        HttpResponse<String> resp = send(build(method, path, body, true));
        ensureSuccess(resp);
        return type == Void.class ? null : parse(resp, type);
    }

    private HttpRequest build(String method, String path, Object body, boolean auth) throws ApiException {
        URI uri;
        try {
            uri = URI.create(baseUrl + path);
        } catch (IllegalArgumentException e) {
            throw new ApiException(ApiException.Kind.CONNECTION, "Некорректный адрес подключения. Проверьте настройки подключения.", e);
        }
        HttpRequest.Builder b = HttpRequest.newBuilder(uri)
                .timeout(REQUEST_TIMEOUT)
                .header("Accept", "application/json");

        if (auth && session != null) {
            b.header("Authorization", "Bearer " + session.token());
        }
        if (body != null) {
            try {
                String json = mapper.writeValueAsString(body);
                b.header("Content-Type", "application/json; charset=UTF-8");
                b.method(method, HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8));
            } catch (JsonProcessingException e) {
                throw new ApiException(ApiException.Kind.BAD_REQUEST, "Не удалось подготовить запрос.", e);
            }
        } else {
            b.method(method, HttpRequest.BodyPublishers.noBody());
        }
        return b.build();
    }

    private HttpResponse<String> send(HttpRequest request) throws ApiException {
        try {
            return http.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        } catch (HttpConnectTimeoutException | ConnectException e) {
            throw new ApiException(ApiException.Kind.CONNECTION,
                    "Нет соединения. Проверьте подключение к сети и попробуйте ещё раз.", e);
        } catch (HttpTimeoutException e) {
            throw new ApiException(ApiException.Kind.CONNECTION, "Превышено время ожидания. Попробуйте ещё раз.", e);
        } catch (IOException e) {
            throw new ApiException(ApiException.Kind.CONNECTION,
                    "Ошибка соединения. Попробуйте ещё раз.", e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ApiException(ApiException.Kind.CONNECTION, "Запрос прерван.", e);
        }
    }

    private void ensureSuccess(HttpResponse<String> resp) throws ApiException {
        int code = resp.statusCode();
        if (code >= 200 && code < 300) {
            return;
        }
        String serverMessage = extractMessage(resp.body());
        switch (code) {
            case 401 -> throw new ApiException(ApiException.Kind.UNAUTHORIZED, code,
                    "Сессия истекла или недействительна. Войдите снова.");
            case 403 -> throw new ApiException(ApiException.Kind.FORBIDDEN, code,
                    "Недостаточно прав для выполнения этого действия.");
            case 404 -> throw new ApiException(ApiException.Kind.NOT_FOUND, code,
                    "Запись не найдена — возможно, она уже удалена.");
            case 400 -> throw new ApiException(ApiException.Kind.BAD_REQUEST, code,
                    "Проверьте правильность введённых данных." + suffix(serverMessage));
            default -> throw new ApiException(ApiException.Kind.SERVER, code,
                    "Не удалось выполнить действие. Попробуйте позже.");
        }
    }

    private <T> T parse(HttpResponse<String> resp, Class<T> type) throws ApiException {
        String body = resp.body();
        if (body == null || body.isBlank()) {
            return null;
        }
        try {
            return mapper.readValue(body, type);
        } catch (JsonProcessingException e) {
            throw new ApiException(ApiException.Kind.SERVER, "Не удалось загрузить данные. Попробуйте ещё раз.", e);
        }
    }

    private String extractMessage(String body) {
        if (body == null || body.isBlank()) {
            return null;
        }
        try {
            AppError err = mapper.readValue(body, AppError.class);
            if (err.message() != null && !err.message().isBlank()) {
                return err.message();
            }
            return err.error();
        } catch (JsonProcessingException e) {
            return null;
        }
    }

    private static String suffix(String serverMessage) {
        // Технические сообщения пользователю не показываем — только понятный текст на русском.
        if (serverMessage == null || !serverMessage.matches("(?s).*[А-Яа-яЁё].*")) {
            return "";
        }
        return "\n" + serverMessage;
    }

    static String normalizeBaseUrl(String url) {
        String u = url == null ? "" : url.trim();
        if (u.isEmpty()) {
            return DEFAULT_BASE_URL;
        }
        if (!u.matches("(?i)^https?://.*")) {
            u = "http://" + u;
        }
        while (u.endsWith("/")) {
            u = u.substring(0, u.length() - 1);
        }
        return u;
    }
}
