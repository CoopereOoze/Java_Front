package com.example.studentclient.ui;

import com.example.studentclient.AppContext;
import com.example.studentclient.api.ApiClient;
import com.example.studentclient.api.Role;
import com.example.studentclient.api.dto.Dto.StudentFull;
import com.example.studentclient.api.dto.Dto.StudentShort;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.VBox;
import javafx.stage.Window;

import java.util.Locale;
import java.util.Objects;

/**
 * Вкладка «Студенты».
 * ADMIN — создание, изменение (телефон и email), удаление; TEACHER — только просмотр.
 */
public class StudentsController {
    @FXML private TextField searchField;
    @FXML private Label modeLabel;
    @FXML private Button refreshButton;
    @FXML private Button addButton;
    @FXML private Button editButton;
    @FXML private Button deleteButton;

    @FXML private TableView<StudentShort> table;
    @FXML private TableColumn<StudentShort, Number> idColumn;
    @FXML private TableColumn<StudentShort, String> nameColumn;
    @FXML private TableColumn<StudentShort, String> surnameColumn;
    @FXML private Label tablePlaceholder;

    @FXML private VBox detailEmpty;
    @FXML private VBox detailContent;
    @FXML private Label avatarLabel;
    @FXML private Label detailName;
    @FXML private Label detailId;
    @FXML private Label detailPhone;
    @FXML private Label detailEmail;
    @FXML private Label detailError;
    @FXML private ProgressIndicator detailProgress;

    @FXML private Label countLabel;
    @FXML private ProgressIndicator loadingIndicator;

    private final ApiClient api = AppContext.api();
    private final ObservableList<StudentShort> items = FXCollections.observableArrayList();
    private FilteredList<StudentShort> filtered;
    private boolean canEdit;
    private int totalCount;

    /** Полные данные выбранного студента (null, пока не загружены). */
    private StudentFull currentDetail;

    @FXML
    private void initialize() {
        canEdit = api.session().hasRole(Role.ADMIN);

        idColumn.setCellValueFactory(c -> new SimpleLongProperty(c.getValue().id()));
        nameColumn.setCellValueFactory(c -> new SimpleStringProperty(Ui.orDash(c.getValue().name())));
        surnameColumn.setCellValueFactory(c -> new SimpleStringProperty(Ui.orDash(c.getValue().surname())));

        filtered = new FilteredList<>(items, s -> true);
        SortedList<StudentShort> sorted = new SortedList<>(filtered);
        sorted.comparatorProperty().bind(table.comparatorProperty());
        table.setItems(sorted);
        table.getSortOrder().add(idColumn);

        searchField.textProperty().addListener((o, a, text) -> applyFilter(text));

        for (Button b : new Button[]{addButton, editButton, deleteButton}) {
            b.setVisible(canEdit);
            b.setManaged(canEdit);
        }
        modeLabel.setVisible(!canEdit);
        modeLabel.setManaged(!canEdit);
        editButton.disableProperty().bind(table.getSelectionModel().selectedItemProperty().isNull());
        deleteButton.disableProperty().bind(table.getSelectionModel().selectedItemProperty().isNull());

        table.getSelectionModel().selectedItemProperty().addListener((o, old, selected) -> showDetails(selected));
        table.setRowFactory(tv -> {
            TableRow<StudentShort> row = new TableRow<>();
            row.setOnMouseClicked(e -> {
                if (canEdit && e.getButton() == MouseButton.PRIMARY && e.getClickCount() == 2 && !row.isEmpty()) {
                    onEdit();
                }
            });
            return row;
        });
        table.setOnKeyPressed(e -> {
            if (canEdit && e.getCode() == KeyCode.DELETE && table.getSelectionModel().getSelectedItem() != null) {
                onDelete();
            }
        });

        showDetails(null);
        reload(null);
    }

    // ===================== Действия =====================

    @FXML
    private void onRefresh() {
        StudentShort selected = table.getSelectionModel().getSelectedItem();
        reload(selected == null ? null : selected.id());
    }

    @FXML
    private void onAdd() {
        FXMLLoader loader = AppContext.loader("student-dialog.fxml");
        DialogPane pane = AppContext.load(loader);
        StudentDialogController form = loader.getController();
        form.setupCreate();

        Ui.showForm(window(), "Новый студент", pane, "Создать",
                form::validate,
                () -> api.createStudent(form.buildCreateRequest()),
                form::showError
        ).ifPresent(created -> reload(created.id()));
    }

    @FXML
    private void onEdit() {
        StudentShort selected = table.getSelectionModel().getSelectedItem();
        if (selected == null) {
            return;
        }
        if (currentDetail != null && currentDetail.id() == selected.id()) {
            openEditDialog(currentDetail);
            return;
        }
        // Полные данные ещё не загружены — загружаем и открываем форму.
        setLoading(true);
        Async.run(() -> api.getStudent(selected.id()), full -> {
            setLoading(false);
            openEditDialog(full);
        }, ex -> {
            setLoading(false);
            Ui.showError(window(), ex);
        });
    }

    @FXML
    private void onDelete() {
        StudentShort selected = table.getSelectionModel().getSelectedItem();
        if (selected == null) {
            return;
        }
        boolean ok = Ui.confirm(window(), "Удалить студента?",
                "Студент «" + selected.fullName() + "» (ID " + selected.id() + ") будет удалён без возможности восстановления.",
                "Удалить");
        if (!ok) {
            return;
        }
        setLoading(true);
        Async.run(() -> {
            api.deleteStudent(selected.id());
            return null;
        }, v -> reload(null), ex -> {
            setLoading(false);
            Ui.showError(window(), ex);
        });
    }

    // ===================== Загрузка данных =====================

    private void reload(Long selectId) {
        setLoading(true);
        tablePlaceholder.setText("Загрузка…");
        Async.run(api::getStudents, list -> {
            setLoading(false);
            totalCount = list.totalCount();
            items.setAll(list.response());
            tablePlaceholder.setText("Студентов пока нет");
            updateCount();
            if (selectId != null) {
                select(selectId);
            }
        }, ex -> {
            setLoading(false);
            tablePlaceholder.setText("Не удалось загрузить список");
            Ui.showError(window(), ex);
        });
    }

    private void showDetails(StudentShort selected) {
        currentDetail = null;
        boolean has = selected != null;
        detailEmpty.setVisible(!has);
        detailContent.setVisible(has);
        if (!has) {
            return;
        }
        // Сразу показываем то, что уже известно, остальное догружаем.
        detailName.setText(selected.fullName().isEmpty() ? "Без имени" : selected.fullName());
        detailId.setText("ID " + selected.id());
        avatarLabel.setText(initials(selected.name(), selected.surname()));
        detailPhone.getStyleClass().remove("empty-value");
        detailEmail.getStyleClass().remove("empty-value");
        detailPhone.setText("…");
        detailEmail.setText("…");
        Ui.setError(detailError, null);
        detailProgress.setVisible(true);

        long id = selected.id();
        Async.run(() -> api.getStudent(id), full -> {
            if (!isStillSelected(id)) {
                return; // пользователь уже выбрал другую строку
            }
            detailProgress.setVisible(false);
            currentDetail = full;
            detailName.setText(full.fullName().isEmpty() ? "Без имени" : full.fullName());
            setValue(detailPhone, full.phoneNumber());
            setValue(detailEmail, full.email());
        }, ex -> {
            if (!isStillSelected(id)) {
                return;
            }
            detailProgress.setVisible(false);
            detailPhone.setText("—");
            detailEmail.setText("—");
            if (Ui.isUnauthorized(ex)) {
                Ui.showError(window(), ex);
            } else {
                Ui.setError(detailError, Ui.message(ex));
            }
        });
    }

    private void openEditDialog(StudentFull student) {
        FXMLLoader loader = AppContext.loader("student-dialog.fxml");
        DialogPane pane = AppContext.load(loader);
        StudentDialogController form = loader.getController();
        form.setupEdit(student);

        Ui.showForm(window(), "Изменение студента", pane, "Сохранить",
                form::validate,
                () -> api.updateStudent(student.id(), form.buildUpdateRequest()),
                form::showError
        ).ifPresent(updated -> reload(student.id()));
    }

    // ===================== Вспомогательное =====================

    private void applyFilter(String text) {
        String q = text == null ? "" : text.trim().toLowerCase(Locale.ROOT);
        filtered.setPredicate(s -> q.isEmpty()
                || String.valueOf(s.id()).equals(q)
                || contains(s.name(), q)
                || contains(s.surname(), q)
                || s.fullName().toLowerCase(Locale.ROOT).contains(q));
        updateCount();
    }

    private void updateCount() {
        String text = "Всего студентов: " + totalCount;
        if (filtered.size() != items.size()) {
            text += "  ·  найдено: " + filtered.size();
        }
        countLabel.setText(text);
    }

    private void select(long id) {
        for (StudentShort s : table.getItems()) {
            if (s.id() == id) {
                table.getSelectionModel().select(s);
                table.scrollTo(s);
                return;
            }
        }
    }

    private boolean isStillSelected(long id) {
        StudentShort s = table.getSelectionModel().getSelectedItem();
        return s != null && s.id() == id;
    }

    private void setLoading(boolean loading) {
        loadingIndicator.setVisible(loading);
        refreshButton.setDisable(loading);
    }

    private static void setValue(Label label, String value) {
        boolean empty = value == null || value.isBlank();
        label.setText(empty ? "не указан" : value);
        label.getStyleClass().remove("empty-value");
        if (empty) {
            label.getStyleClass().add("empty-value");
        }
    }

    private static boolean contains(String value, String q) {
        return value != null && value.toLowerCase(Locale.ROOT).contains(q);
    }

    private static String initials(String name, String surname) {
        String a = name == null || name.isBlank() ? "" : name.substring(0, 1);
        String b = surname == null || surname.isBlank() ? "" : surname.substring(0, 1);
        String r = (a + b).toUpperCase(Locale.ROOT);
        return r.isEmpty() ? "?" : r;
    }

    private Window window() {
        return Objects.requireNonNull(table.getScene()).getWindow();
    }
}
