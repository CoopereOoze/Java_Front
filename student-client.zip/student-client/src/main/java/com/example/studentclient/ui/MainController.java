package com.example.studentclient.ui;

import com.example.studentclient.AppContext;
import com.example.studentclient.api.Role;
import com.example.studentclient.api.Session;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 * Главное окно. Вкладки показываются в соответствии с правами на сервере:
 *  - «Студенты»: ADMIN (полный доступ) и TEACHER (только просмотр);
 *  - «Пользователи»: только SUPER_ADMIN.
 */
public class MainController {
    @FXML private Label userLabel;
    @FXML private HBox rolesBox;
    @FXML private TabPane tabPane;
    @FXML private VBox noAccessBox;

    @FXML
    private void initialize() {
        Session session = AppContext.api().session();
        userLabel.setText(session.email());
        for (Role role : session.roles()) {
            Label chip = new Label(role.title());
            chip.getStyleClass().addAll("chip", "chip-" + role.name().toLowerCase().replace('_', '-'));
            rolesBox.getChildren().add(chip);
        }

        if (session.hasAnyRole(Role.ADMIN, Role.TEACHER)) {
            tabPane.getTabs().add(new Tab("Студенты", AppContext.<Parent>load(AppContext.loader("students.fxml"))));
        }
        if (session.hasRole(Role.SUPER_ADMIN)) {
            tabPane.getTabs().add(new Tab("Пользователи", AppContext.<Parent>load(AppContext.loader("users.fxml"))));
        }

        boolean empty = tabPane.getTabs().isEmpty();
        tabPane.setVisible(!empty);
        noAccessBox.setVisible(empty);
        noAccessBox.setManaged(empty);
    }

    @FXML
    private void onLogout() {
        AppContext.showLogin(null);
    }
}
