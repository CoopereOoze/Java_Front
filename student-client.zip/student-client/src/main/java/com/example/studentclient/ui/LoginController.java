package com.example.studentclient.ui;

import com.example.studentclient.AppContext;
import com.example.studentclient.api.ApiClient;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;

import java.util.prefs.Preferences;

public class LoginController {
    private static final String PREF_SERVER = "serverUrl";
    private static final String PREF_EMAIL = "lastEmail";

    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private TitledPane serverPane;
    @FXML private TextField serverField;
    @FXML private Label messageLabel;
    @FXML private Label errorLabel;
    @FXML private Button loginButton;

    @FXML
    private void initialize() {
        Preferences prefs = AppContext.prefs();
        String server = prefs.get(PREF_SERVER, ApiClient.DEFAULT_BASE_URL);
        serverField.setText(server);
        serverPane.setExpanded(!ApiClient.DEFAULT_BASE_URL.equals(server));
        emailField.setText(prefs.get(PREF_EMAIL, ""));

        emailField.textProperty().addListener((o, a, b) -> Ui.setError(errorLabel, null));
        passwordField.textProperty().addListener((o, a, b) -> Ui.setError(errorLabel, null));

        Platform.runLater(() -> (emailField.getText().isEmpty() ? emailField : passwordField).requestFocus());
    }

    /** Сообщение над формой, например «Сессия истекла». */
    public void setMessage(String message) {
        Ui.setError(messageLabel, message);
    }

    @FXML
    private void onLogin() {
        String email = emailField.getText().trim();
        String password = passwordField.getText();
        String server = serverField.getText().trim();

        if (email.isEmpty() || password.isEmpty()) {
            Ui.setError(errorLabel, "Введите email и пароль.");
            return;
        }
        if (!Ui.EMAIL.matcher(email).matches()) {
            Ui.setError(errorLabel, "Некорректный email.");
            return;
        }

        setBusy(true);
        Async.run(() -> AppContext.api().login(server, email, password), session -> {
            Preferences prefs = AppContext.prefs();
            prefs.put(PREF_SERVER, AppContext.api().baseUrl());
            prefs.put(PREF_EMAIL, email);
            AppContext.showMain();
        }, ex -> {
            setBusy(false);
            Ui.setError(errorLabel, Ui.message(ex));
            passwordField.requestFocus();
            passwordField.selectAll();
        });
    }

    private void setBusy(boolean busy) {
        loginButton.setDisable(busy);
        loginButton.setText(busy ? "Вход…" : "Войти");
        emailField.setDisable(busy);
        passwordField.setDisable(busy);
        serverField.setDisable(busy);
        if (busy) {
            Ui.setError(messageLabel, null);
        }
    }
}
